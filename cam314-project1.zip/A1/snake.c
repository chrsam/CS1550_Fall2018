/*
 * Project 1: Graphics Library
 * CS 1550 - Fall 2018
 * Author: Chris Mananghaya (cam314@pitt.edu)
 */

#include "graphics.h"
#include "library.c" // import graphics library 

int main() {

	void *buffer;
	char key; 

	init_graphics(); 

	buffer = new_offscreen_buffer(); 

	draw_pixel(buffer, 200, 250, RGB(98, 170, 33));
	blit(buffer); 

	sleep_ms(1000); 
	clear_screen(buffer); 

	while(key != 'q') {
		key = getkey();
		if(key == 'l') {
			draw_line(buffer, 50, 50, 50, 100, RGB(172, 37, 64));
			blit(buffer); 
		}
		sleep_ms(1000); 
	}

	exit_graphics();
	return 0; 
}

