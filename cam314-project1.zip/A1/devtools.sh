#!/bin/sh

tce-load -wi openssh.tcz gcc-locale.tcz gdb-locale.tcz eglibc_base-dev.tcz
